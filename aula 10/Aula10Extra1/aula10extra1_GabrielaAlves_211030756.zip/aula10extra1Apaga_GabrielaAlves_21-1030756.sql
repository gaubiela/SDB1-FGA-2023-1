-- -------- <  Exercício Extra 1 da Aula 10 > --------
--
--                    SCRIPT APAGA
--
-- Data Criacao ...........: 18/06/2023
-- Autor(es) ..............: Gabriela Silva Alves
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula10extra1
--
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
-- 
-- Ultimas Alteracoes
--   18/06/2023 => Criação
--
-- ---------------------------------------------------------
USE aula10extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;